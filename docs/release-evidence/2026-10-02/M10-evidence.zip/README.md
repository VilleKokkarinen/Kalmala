# Kalmala M10 release evidence

Capture date: 2026-10-02. This evidence bundle accompanies the M10 release-completion handoff in the repository PROGRESS.md.

## Package build

The package was built with Unreal Engine 5.8.2 as Win64 Development from a disposable project mirror. BuildCookRun completed successfully in 296.16 seconds, compiled 358 actions, cooked 514 of 521 packages, and produced 48 non-Saved package files totaling 970,637,056 bytes. The maximum package path recorded at build time was 140 characters. Raw BuildCookRun output and all three package manifests are in build/.

The package binary is not copied into this source repository. Its original local output was C:\Users\Ville\AppData\Local\Temp\kca\Archive\Windows. The current local output directory has since been launched for verification and contains extra runtime Saved logs/configuration/save files; package-files.sha256.csv fingerprints only the 48 built files outside Saved. Do not distribute that mutated temp directory as a clean release archive.

The full null-renderer smoke log records Engine Initialized and loading of /Game/Kalmala/Maps/Prototype/L_Prototype, with zero lines containing Error:. The recorded run remained alive for more than 20 seconds. It also records 21 warnings, including missing audio cue assets and an invalid default skiff hull material index. These warnings are retained as known candidate limitations for release review; smoke success is not a claim of complete packaged audio or material quality.

## Test evidence

- tests/full-automation.log records 98 successful Kalmala automation tests, zero failed tests, and exit code 0.
- tests/camp-build.log and tests/camp-focused.log retain the focused M10 camp-tradeoff fixture/build evidence.
- tests/schema2-reconnect/ contains the six host, owner, and observer logs from the M9 schema-2 candidate migration/reconnect acceptance.
- tests/ocean-journey/ contains the host, owner, and late-join logs from the integrated long-distance ocean journey/restart scenario.
- render/accessibility/ contains six host/client settings captures plus their logs.
- render/world-map/ contains host/client captures and logs at 1024x768, 1280x720, and 2560x1080.
- playtest/ contains logs from the earlier partial packaged peer-control attempt. They show a joined host/client session but do not establish normal-action progression or travel.

The product owner's 2026-10-02 confirmation that the fresh-player packaged co-op, extended progression, and long-distance walkthrough was completed manually is recorded in PROGRESS.md. No per-step screenshots, timings, or manual-session logs were supplied, so this archive does not invent them.

## Frozen contracts and runbooks

Point-in-time copies of the project brief, game design, technical architecture, roadmap, decision log, development setup, vertical-slice runbook, accessibility contract, M8 performance report, M9 save migration contract, M10 scope freeze, and constrained-profile report are in reference/docs/. The migration baseline keeps schema-2 construction and player-discovery saves with explicit schema-1 migration, exact seed/revision/scope matching, and the schema-4 item/recipe catalogue. No save or network contract changed during evidence archiving.

The reproducible Windows Development build and fresh-profile smoke procedure is in reference/docs/07-development-setup.md. It requires a disposable short-path mirror, UE 5.8.2 BuildCookRun with -pak and -iostore, then a new empty UserDir and absolute log for the 20-second null-renderer startup/map-load check.

## Known limits

- The M10 manual walkthrough is owner-reported; the agent did not independently observe the complete journey.
- Dedicated-server validation was skipped because the installed Launcher Unreal distribution has no dedicated-server capability.
- No game-managed save backup/restore path is defined. Migration and malformed-load rejection preserve source state, but backup recovery was not exercised.
- The owner accepted the one-machine and simulated-profile performance evidence with its limits. Physical low/mid-tier hardware, numerical release ceilings, packaged extended travel, long-session peak/growth, and expanded worker/raster coverage remain unverified.
- The package smoke warnings listed above remain in the raw log.
- The package source mirror was disposable and had no immutable source revision in the build metadata. The source-state note records the repository base commit and dirty paths at archive-task start; the binary hash manifest supports local integrity checks but cannot recreate deleted source.

## Contents and integrity

evidence-manifest.csv lists every copied evidence file, its original path, byte count, and SHA-256. build/package-files.sha256.csv fingerprints the package output files outside Saved. No save files, generated intermediate directories, or package binaries are included. The outer repository handoff adds its own archive SHA-256 after the zip is created.